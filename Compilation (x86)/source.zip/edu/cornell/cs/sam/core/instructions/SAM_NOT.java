package edu.cornell.cs.sam.core.instructions;

/**
 * Negates an integer (logical NOT)
 */

public class SAM_NOT extends SAM_ISNIL {
}
