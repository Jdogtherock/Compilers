// Program 2: Double for loop

#include <iostream>

int main()
{
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            std::cout << i << " " << j << std::endl;
        }
    }
    return 0;
}