For this assignment, I thoroughly read through the LLVM getting started page, the code for the
class and object functions, as well as some of the code in the src/build folders in order to see
which methods would be the best to use. This submission passed all of the test cases that I created,
with correctness and completeness. The most challenging part of this project was definitely building it
at first, and then finding all of the functions that the classes have (such as getParentLoop, isAtomic, ETC).
The LLVM pages for that isnt the most user friendly, so I ran into a lot of debugging when implementing
the functions. Other than that, the logic for the functions were straightforward. The test cases that I created
and used are in the src folder.